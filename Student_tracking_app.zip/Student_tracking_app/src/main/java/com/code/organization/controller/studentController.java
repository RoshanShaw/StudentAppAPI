package com.code.organization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.code.organization.entity.student;
import com.code.organization.implementation.StudentServiceImpl;

@RestController
public class studentController {
	@Autowired
	StudentServiceImpl service;
	
	@GetMapping("/student")
	public List<student> getAllStudents()
	{
		List<student> s=this.service.getAllStudent();
		return s;
	}
	@PostMapping("/student")
	public student createAStudent(@RequestBody student s)
	{
		student s1=this.service.createStudent(s);
		return s1;
	}

}
