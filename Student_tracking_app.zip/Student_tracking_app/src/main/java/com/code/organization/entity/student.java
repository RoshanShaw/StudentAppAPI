package com.code.organization.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class student {
	
	@Id
	private int id;
	private String name;
	private String address;
	private String hobby;
	

}
