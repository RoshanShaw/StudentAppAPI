package com.code.organization.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.organization.entity.student;
import com.code.organization.repo.studentRepo;
import com.code.organization.service.studentService;

@Service
public class StudentServiceImpl implements studentService {
	@Autowired
	studentRepo repo;

	@Override
	public List<student> getAllStudent() 
	{
		List<student> student=this.repo.findAll();
		return student;
		
	}

	@Override
	public student createStudent(student s) {
		
		@SuppressWarnings("unchecked")
		student savedStudent= (student) this.repo.save(s);
		
		return savedStudent;
	}

}
