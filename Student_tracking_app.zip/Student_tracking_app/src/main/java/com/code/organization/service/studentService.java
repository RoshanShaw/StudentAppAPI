package com.code.organization.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.code.organization.entity.student;
@Service
public interface studentService {
	
	public List<student> getAllStudent();
	public student createStudent(student s);

}
