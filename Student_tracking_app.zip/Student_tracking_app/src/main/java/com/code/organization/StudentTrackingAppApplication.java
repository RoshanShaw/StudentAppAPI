package com.code.organization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentTrackingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentTrackingAppApplication.class, args);
	}

}
